const auth = () => {};

module.exports = {
  auth,
};

//+1
